//
//  EstgfarApp.swift
//  Estgfar
//
//  Created by Ahmed Salah on 14/08/2022.
//

import SwiftUI

@main
struct EstgfarApp: App {
    
    init(){
        UINavigationBar.appearance().backgroundColor = .white
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
