//
//  Page2.swift
//  Estgfar
//
//  Created by Ahmed Salah on 15/08/2022.
//

import SwiftUI

struct Page2: View {
    
    @AppStorage("T4") var Count = 0
    
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.blue , Color.white]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
            
                .ignoresSafeArea()
            
            
            
            VStack{
                Text("\(Count)")
                    .foregroundColor(.blue)
                    .font(.system(size: 60))
                    .fontWeight(.heavy)
                    .padding(.top , 200)
                    .shadow(color: .white, radius: 9)
            
            
            Spacer()
            
            HStack{
                
                
                
                Button(action: { Count += 1 }) {
                    Text("استغفر الله")
                }
                .frame(width: 100, height: 100)
                .foregroundColor(.white)
                .padding()
                .shadow(color: .black, radius: 9)
                .background(.blue)
                .cornerRadius(100)
                .padding(.leading , 30)
                
                
                Spacer()
                
                Button(action: { re() }) {
                    Text("اعادة")
                }
                .frame(width: 100, height: 100)
                .foregroundColor(.white)
                .padding()
                .shadow(color: .black, radius: 9)
                .background(.blue)
                .cornerRadius(100)
                .padding(.trailing , 30)
                
                
               
                
            }
                Spacer()
                
                
                
                
                
                
            
            }
            
        }
    }
    
    func re(){
        Count = 0
    }
    
    
}

struct Page2_Previews: PreviewProvider {
    static var previews: some View {
        Page2()
    }
}
