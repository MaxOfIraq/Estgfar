//
//  ContentView.swift
//  Estgfar
//
//  Created by Ahmed Salah on 14/08/2022.
//

import SwiftUI

struct ContentView: View {
    
    @AppStorage("T1") var tasbeh1 = 0
    @AppStorage("T2") var tasbeh2 = 0
    @AppStorage("T3") var tasbeh3 = 0
    
    @State var isAleart = false
    
    var total : CGFloat{
        return CGFloat(tasbeh1 + tasbeh2 + tasbeh3)
    }
    
    
    var body: some View {
        NavigationView {
            ZStack {
                
                LinearGradient(gradient: Gradient(colors: [Color.blue , Color.white]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                
                    .ignoresSafeArea()
                   
                VStack {
                    
                    ZStack {
                        
                        Circle()
                            .stroke(lineWidth: 10.0)
                            .foregroundColor(.white)
                            .frame(width: 150, height: 150)
                            .opacity(0.3)
                            .padding()
                        Circle()
                            .trim(from: 0.0 , to: total / 100)
                            .stroke(style: StrokeStyle(lineWidth: 10.0, lineCap: .round, lineJoin: .round))
                            .frame(width: 150, height: 150)
                            .foregroundColor(.blue)
                        
                        
                        
                        Text("\(Int(total))")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                    }
                    
                    
                    Button(action: { tasbeh1 += 1
                        chack()
                    }) {
                        Text("سبحان الله")
                    }.disabled(tasbeh1 >= 33)
                    .frame(width: 90, height: 30)
                    .foregroundColor(.white)
                    .padding()
                    .border(Color.black , width: 2)
                    .background(.blue)
                    .cornerRadius(10)
                    
                    .padding()
                    
                    Button(action: { tasbeh2 += 1
                        chack()
                    }) {
                        Text("الحمد لله")
                    }.disabled(tasbeh2 >= 33)
                    .frame(width: 90, height: 30)
                    .foregroundColor(.white)
                    .padding()
                    .border(Color.black , width: 2)
                    .background(.blue)
                    .cornerRadius(10)
                    
                    .padding()
                    
                    Button(action: { tasbeh3 += 1
                        chack()
                    }) {
                        Text("الله اكبر")
                    }.disabled(tasbeh3 >= 33)
                    .frame(width: 90, height: 30)
                    .foregroundColor(.white)
                    .padding()
                    .border(Color.black , width: 2)
                    .background(.blue)
                    .cornerRadius(10)
                    
                    
                    
                    
                    Spacer()
                    
                    HStack{
                        
                        Button(action: { re() }) {
                           Text("اعادة")
                        }
                        .frame(width: 90, height: 30)
                        .foregroundColor(.white)
                        .padding()
                        .border(Color.black , width: 2)
                        .background(.blue)
                        .cornerRadius(10)
                        
                        
                        .padding(.leading, 40)
                        
                        Spacer()
                        
                        
                        
                        NavigationLink(destination: Page2()){
                            Text("الاستغفار")
                        }
                        .frame(width: 90, height: 30)
                        .foregroundColor(.white)
                        .padding()
                        .border(Color.black , width: 2)
                        .background(.blue)
                        .cornerRadius(10)
                        
                        
                        
                        .padding(.trailing, 40)
                    }
                    Spacer()
                }
            }
            .alert(isPresented: $isAleart){
                Alert(title: Text("Im Ahmed  Salah"))
            
            
        }
            
            
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarTitle("Ahmed")
            
        }
        
    }
    
    func chack(){
        if (tasbeh1 + tasbeh2 + tasbeh3) == 99{
            tasbeh1 = 0
            tasbeh2 = 0
            tasbeh3 = 0
            
            isAleart.toggle()
        }
    }
    
    func re(){
        tasbeh1 = 0
        tasbeh2 = 0
        tasbeh3 = 0
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
